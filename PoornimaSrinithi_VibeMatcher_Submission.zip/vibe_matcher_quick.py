
# vibe_matcher_quick.py - TF-IDF prototype
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

products = [
    {"id":1,"name":"Boho Dress","desc":"Flowy maxi dress, earthy tones, floral prints — perfect for festival and beachy bohemian vibes.","tags":["boho","festival","earthy"]},
    {"id":2,"name":"Urban Bomber Jacket","desc":"Cropped bomber with edgy zip details, black matte finish — energetic urban chic for nights out.","tags":["urban","chic","edgy"]},
    {"id":3,"name":"Cozy Knit Sweater","desc":"Thick knit, oversized fit, neutral beige — comfortable, cozy, and laid-back weekend essential.","tags":["cozy","casual","winter"]},
    {"id":4,"name":"Minimalist Blouse","desc":"Crisp white blouse with clean lines and subtle tailoring — minimalist, professional, versatile.","tags":["minimal","workwear","clean"]},
    {"id":5,"name":"Athleisure Leggings","desc":"High-waist stretch leggings with breathable fabric — sporty, energetic, and comfortable for urban runs.","tags":["athleisure","sporty","energetic"]}
]
df = pd.DataFrame(products)
vectorizer = TfidfVectorizer(ngram_range=(1,2), stop_words='english')
emb = vectorizer.fit_transform(df['desc'].tolist())
def match_vibe(q,k=3):
    sims = cosine_similarity(vectorizer.transform([q]), emb).flatten()
    idx = sims.argsort()[::-1][:k]
    return [(df.iloc[i]['name'], float(sims[i])) for i in idx]
if __name__ == '__main__':
    queries = ['energetic urban chic','laid-back cozy weekend','sleek evening glamour']
    for q in queries:
        print('Query:',q, match_vibe(q))
